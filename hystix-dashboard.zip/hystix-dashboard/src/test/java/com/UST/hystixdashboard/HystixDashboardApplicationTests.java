package com.UST.hystixdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystixDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
